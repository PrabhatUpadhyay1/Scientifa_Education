package com.prabhat.mainactivity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Chat_Page extends AppCompatActivity {
    FirebaseFirestore firestore;
    String sender,receiver,message,id,lastSender;
    FirebaseAuth auth;
    RecyclerView recyclerView;
    DocumentReference documentReference;
    List<modelChat> list;
    ImageView send;
    chatAdapter adapter;
    Snackbar snackbar;
    ConstraintLayout layout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        send=findViewById(R.id.send);
        final EditText msg=findViewById(R.id.msg);

        auth=FirebaseAuth.getInstance();
        firestore=FirebaseFirestore.getInstance();
        layout=findViewById(R.id.chatLayout);
        sender= auth.getCurrentUser().getEmail();
        Intent intent=getIntent();
        receiver=intent.getStringExtra("email");
        id=intent.getStringExtra("id");
        final TextView name=findViewById(R.id.profienameeditText);
        name.setText(intent.getStringExtra("customer"));

        recyclerView=findViewById(R.id.recyclerView);
        list=new ArrayList<>();
        adapter=new chatAdapter(list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
        documentReference =firestore.collection("Chats").document(id).collection(sender).document();



/////***************Back Pressed////////////***************////
        ImageView back=findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

////////************send Message****************/////////
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                message=msg.getText().toString().trim();
                sendMessage(message);
                msg.setText("");

            }
        });
    }
//////////*/*****send menthod************//////////////////
    private void sendMessage(final String message) {
        if(sender.equals(receiver)){
            HashMap<String, Object> hashMap1 = new HashMap<>();
            hashMap1.put("message", message);
            hashMap1.put("sender", sender);
            hashMap1.put("receiver",lastSender);
            hashMap1.put("id", id);

//            Toast.makeText(this, lastSender, Toast.LENGTH_LONG).show();
            if(lastSender==null){
                snackbar.make(layout,"You can't send msg to yourself",Snackbar.LENGTH_LONG)
                        .setAction("Close", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                               finish();
                            }
                        })
                        .setActionTextColor(getResources().getColor(R.color.White))
                        .setDuration(2000)
                        .show();
            }
            else {
            firestore.collection("Chats").document(lastSender).collection(id).document()
                    .set(hashMap1).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    HashMap<String, Object> hashMap1 = new HashMap<>();
                    hashMap1.put("message", message);
                    hashMap1.put("sender", sender);
                    hashMap1.put("receiver",lastSender);
                    hashMap1.put("id", id);
                    firestore.collection("Chats").document(sender).collection(id).document()
                            .set(hashMap1).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {

                        }
                    });

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                }
            });
        }
        }

        final HashMap<String,String> hashMap=new HashMap<>();
        hashMap.put("message",message);
        hashMap.put("sender",sender);
        hashMap.put("id",id);
        hashMap.put("receiver",receiver);
         if(!sender.equals(receiver)) {
            firestore.collection("Chats").document(sender).collection(id).document()
                    .set(hashMap).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    HashMap<String, Object> hashMap1 = new HashMap<>();
                    hashMap1.put("message", message);
                    hashMap1.put("sender", sender);
                    hashMap1.put("id", id);
                    hashMap1.put("receiver",receiver);
                    firestore.collection("Chats").document(receiver).collection(id).document()
                            .set(hashMap1).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {

                        }
                    });
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                }
            });
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        getMessage();
    }

    private void getMessage() {
        firestore.collection("Chats").document(sender).collection(id).addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                if(e!=null) {

                }

                for(DocumentChange documentChange:queryDocumentSnapshots.getDocumentChanges()){
                    modelChat model=documentChange.getDocument().toObject(modelChat.class);
                    lastSender=model.getSender();
                    if(model.getId().equals(id)){

                    list.add(model);

                    }
                    adapter.notifyDataSetChanged();
                }

            }
        });

    }
}
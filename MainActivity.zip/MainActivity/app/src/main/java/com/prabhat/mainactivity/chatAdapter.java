package com.prabhat.mainactivity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;

import java.util.List;

public class chatAdapter extends RecyclerView.Adapter<chatAdapter.viewHolder> {
    FirebaseAuth auth=FirebaseAuth.getInstance();
    public int right =1;
    public int left =0;
    public chatAdapter(List<modelChat> list) {
        this.list = list;
    }

    public List<modelChat> list;
    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.right,parent,false);
        return new viewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {
    if (list.get(position).sender.equals(auth.getCurrentUser().getEmail())) {
        holder.first.setText(list.get(position).getMessage());
        holder.first.setBackgroundResource(R.drawable.msg);
      }
      else {
            holder.secong.setText(list.get(position).getMessage());
            holder.secong.setBackgroundResource(R.drawable.secong);
      }
    }



    @Override
    public int getItemCount() {
        return list.size();

    }

    public class viewHolder extends RecyclerView.ViewHolder{
        TextView first;
        TextView secong;
        public viewHolder(@NonNull View itemView) {
            super(itemView);
            first=itemView.findViewById(R.id.first);
            secong=itemView.findViewById(R.id.secong);
        }
    }
}
